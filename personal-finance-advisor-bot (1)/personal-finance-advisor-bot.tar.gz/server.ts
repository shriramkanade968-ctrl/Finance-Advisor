import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));

// Server-side initialization of Gemini SDK
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Helper for model selection
const MODEL_NAME = 'gemini-3.8-flash';

// API: Interactive Advisor Chat
app.post('/api/advisor/chat', async (req: Request, res: Response) => {
  try {
    const { messages, financialSnapshot } = req.body;

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Messages array is required' });
    }

    const systemPrompt = `You are the Personal Finance Advisor Bot, a wise, empathetic, and mathematically precise financial planner.
You provide clear, tailored financial guidance to individuals (such as salaried professionals, college students, and freelancers).

Here is the user's current live financial snapshot:
- Profile Persona: ${financialSnapshot?.persona || 'General'}
- Monthly Income: $${financialSnapshot?.totalIncome?.toFixed(2) || '0.00'}
- Total Expenses to date: $${financialSnapshot?.totalExpenses?.toFixed(2) || '0.00'}
- Net Cash Flow: $${financialSnapshot?.netCashFlow?.toFixed(2) || '0.00'}
- Savings Rate: ${financialSnapshot?.savingsRate?.toFixed(1) || '0'}%
- Categories with Overspending: ${
      financialSnapshot?.overspentCategories?.length > 0
        ? financialSnapshot.overspentCategories.map((c: any) => `${c.category} (Spent: $${c.spent.toFixed(2)}, Limit: $${c.budget.toFixed(2)})`).join(', ')
        : 'None detected'
    }
- Category Expenses Breakdown: ${JSON.stringify(financialSnapshot?.categoryTotals || {})}
- Active Savings Goals: ${
      financialSnapshot?.savingsGoals?.length > 0
        ? financialSnapshot.savingsGoals.map((g: any) => `${g.title} ($${g.currentAmount} / $${g.targetAmount}, Target: ${g.targetDate || 'Ongoing'})`).join('; ')
        : 'None set'
    }

Guidelines:
1. Ground your advice in their actual numbers above.
2. If they are overspending in dining, shopping, subscriptions, or entertainment, give polite, concrete trade-offs and saving steps.
3. Be encouraging, transparent, and structured (use bullet points, bold key figures, suggest small weekly habit adjustments).
4. If they ask about saving, investing, budgeting rules (like 50/30/20), or emergency funds, tailor it to their income level.
5. Keep your tone empowering and friendly, never condescending.`;

    // Format chat history for generateContent
    const formattedHistory = messages.map((m: any) => `${m.role === 'user' ? 'User' : 'Advisor'}: ${m.text}`).join('\n\n');
    const latestUserPrompt = messages[messages.length - 1]?.text || 'Hello!';

    const prompt = `${formattedHistory}\n\nAdvisor:`;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.7,
      },
    });

    const reply = response.text || "I'm here to help you navigate your finances! How can I assist you with your budget or goals today?";

    res.json({ reply });
  } catch (error: any) {
    console.error('Advisor Chat Error:', error);
    res.status(500).json({ error: error.message || 'Failed to generate financial advice' });
  }
});

// API: Deep Financial & Spending Analysis
app.post('/api/advisor/analyze', async (req: Request, res: Response) => {
  try {
    const { financialSnapshot } = req.body;

    const systemPrompt = `You are a Senior Personal Financial Analyst. Perform a thorough financial diagnostic on the provided spending and income snapshot.
Analyze overspending categories, calculate budget adherence, evaluate 50/30/20 rule allocation, compute financial health score (0-100), and formulate an actionable monthly budget plan.

Return your response strictly in valid JSON matching this schema:
{
  "healthScore": number, // 0 to 100
  "status": string, // "Excellent" | "Good" | "Fair" | "Needs Attention"
  "summary": string, // 2-3 sentence overview
  "overspendingCategories": [
    {
      "category": string,
      "spent": number,
      "budget": number,
      "variance": number,
      "severity": string, // "warning" or "critical"
      "advice": string
    }
  ],
  "savingsAnalysis": {
    "actualSavings": number,
    "savingsRate": number,
    "targetRate": number,
    "advice": string
  },
  "budgetRuleComparison": {
    "needs": { "actual": number, "percent": number, "targetPercent": number },
    "wants": { "actual": number, "percent": number, "targetPercent": number },
    "savings": { "actual": number, "percent": number, "targetPercent": number }
  },
  "actionableTips": [string, string, string],
  "nextMonthPlan": {
    "suggestedSavingsTarget": number,
    "categoryCuts": [
      {
        "category": string,
        "current": number,
        "suggested": number,
        "potentialSaving": number
      }
    ]
  }
}`;

    const prompt = `Here is the financial snapshot to analyze:
${JSON.stringify(financialSnapshot, null, 2)}

Provide the JSON analysis.`;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
      },
    });

    let data;
    try {
      data = JSON.parse(response.text || '{}');
    } catch {
      data = {
        healthScore: 78,
        status: 'Good',
        summary: 'Your financial balance is steady, with healthy income covering basic needs, but dining and shopping require light moderation.',
        overspendingCategories: [],
        savingsAnalysis: {
          actualSavings: financialSnapshot.netCashFlow || 500,
          savingsRate: financialSnapshot.savingsRate || 15,
          targetRate: 20,
          advice: 'Aim for a 20% savings rate to accelerate emergency reserve.',
        },
        budgetRuleComparison: {
          needs: { actual: 60, percent: 60, targetPercent: 50 },
          wants: { actual: 25, percent: 25, targetPercent: 30 },
          savings: { actual: 15, percent: 15, targetPercent: 20 },
        },
        actionableTips: [
          'Cap weekly discretionary dining out to avoid month-end creep.',
          'Automate transfer of $150 directly into your emergency fund on payday.',
          'Review recurring app and streaming subscriptions.',
        ],
        nextMonthPlan: {
          suggestedSavingsTarget: 600,
          categoryCuts: [],
        },
      };
    }

    res.json(data);
  } catch (error: any) {
    console.error('Advisor Analysis Error:', error);
    res.status(500).json({ error: error.message || 'Failed to analyze spending' });
  }
});

// API: Parse Natural Language Expense Entry
app.post('/api/advisor/parse-expense', async (req: Request, res: Response) => {
  try {
    const { text, currentDate } = req.body;
    if (!text || typeof text !== 'string') {
      return res.status(400).json({ error: 'Text prompt is required' });
    }

    const systemPrompt = `Extract expense details from the user's natural language input.
Today's date is: ${currentDate || new Date().toISOString().split('T')[0]}.
Supported categories are:
- "Housing"
- "Food & Dining"
- "Groceries"
- "Transportation"
- "Utilities"
- "Entertainment"
- "Healthcare"
- "Shopping"
- "Education"
- "Subscriptions"
- "Personal Care"
- "Debt & Loans"
- "Miscellaneous"

Return strictly JSON matching:
{
  "amount": number,
  "category": string,
  "title": string,
  "date": string // YYYY-MM-DD
}`;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: `Parse this expense note: "${text}"`,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json(parsed);
  } catch (error: any) {
    console.error('Parse Expense Error:', error);
    res.status(500).json({ error: error.message || 'Failed to parse expense' });
  }
});

// API: "Can I Afford This?" Purchase Simulator
app.post('/api/advisor/simulate-purchase', async (req: Request, res: Response) => {
  try {
    const { itemName, cost, category, urgency, financialSnapshot } = req.body;

    const systemPrompt = `You are a financial advisor assessing a potential purchase for a user.
Evaluate whether they can afford it safely based on their live numbers:
- Monthly Income: $${financialSnapshot?.totalIncome || 0}
- Total Expenses so far: $${financialSnapshot?.totalExpenses || 0}
- Current Net Savings Buffer: $${financialSnapshot?.netCashFlow || 0}
- Active Goals: ${JSON.stringify(financialSnapshot?.savingsGoals || [])}
- Category budgets: ${JSON.stringify(financialSnapshot?.categoryLimits || {})}

Purchase Details:
- Item: ${itemName}
- Cost: $${cost}
- Category: ${category}
- Urgency/Importance: ${urgency} (Essential, Nice to Have, Impulse/Luxury)

Output strictly JSON:
{
  "verdict": "SAFE" | "CAUTION" | "NOT_RECOMMENDED",
  "verdictTitle": string,
  "rationale": string,
  "impactOnCashFlow": string,
  "impactOnSavingsGoals": string,
  "recommendedAction": string,
  "alternativeTimeline": string
}`;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: `Assess this purchase: $${cost} for ${itemName} (${category})`,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
      },
    });

    const result = JSON.parse(response.text || '{}');
    res.json(result);
  } catch (error: any) {
    console.error('Purchase Simulation Error:', error);
    res.status(500).json({ error: error.message || 'Failed to simulate purchase' });
  }
});

// Setup Vite middleware in dev or static serving in production
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, () => {
    console.log(`Personal Finance Advisor server running on http://localhost:${PORT}`);
  });
}

startServer();
